const body = document.body;
let count = 0;
const counterElement = document.getElementById("counter");

function updateCounter() {
    count++;
    counterElement.textContent = `Color changes: ${count}`;
}

function setColor(name) {
    body.style.background = name;
    updateCounter();
}

function randomColor() {
    const red = Math.floor(Math.random() * 256);
    const green = Math.floor(Math.random() * 256);
    const blue = Math.floor(Math.random() * 256);
    const color = `rgb(${red}, ${green}, ${blue})`;
    body.style.background = color;
    document.getElementById("random").style.background = color;
    updateCounter();
}